function toggleMenu(){
  const menu = document.getElementById('menu');
  const isOpen = getComputedStyle(menu).display !== 'none';
  menu.style.display = isOpen ? 'none' : 'flex';
}
document.addEventListener('DOMContentLoaded', () => {
  const y = new Date().getFullYear();
  const el = document.getElementById('year');
  if(el) el.textContent = y;
  // Smooth scroll for internal links
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const href = a.getAttribute('href');
      if(href.length > 1){
        e.preventDefault();
        document.querySelector(href).scrollIntoView({behavior:'smooth', block:'start'});
        const menu = document.getElementById('menu');
        if(getComputedStyle(menu).position === 'absolute') menu.style.display = 'none';
      }
    });
  });
});
