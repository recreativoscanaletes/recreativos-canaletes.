# Recreativos Canaletes S.L. — Sitio web (horario + URL actualizados)

Datos incluidos:
- **Atiende:** Jon
- **Teléfono / WhatsApp:** +34 652 350 768 (+34652350768)
- **Email:** recreativoscanaletes@gmail.com
- **Dirección:** Avinguda José Tarí Pomares, 35, C.P. 03294, Elche - Alicante.
- **Horario:** Lunes a Viernes, 8:30–20:30 (urgencias 24/7) (con urgencias 24/7)

URL configurada para GitHub Pages: **https://recreativoscanaletes.github.io/recreativos-canaletes**

## Publicar GRATIS en GitHub Pages

1. Crea un repositorio llamado `recreativos-canaletes` en tu cuenta de GitHub **recreativoscanaletes**.
2. Sube los archivos de esta carpeta.
3. Ve a **Settings → Pages**, elige **Branch: `main`** y carpeta **`/`**.
4. Guarda. Tu web aparecerá en: https://recreativoscanaletes.github.io/recreativos-canaletes/

### Conectar dominio propio (opcional, de pago)
Compra un dominio en el registrador que prefieras y, en **Settings → Pages → Custom domain**, introdúcelo. El hosting sigue siendo gratis.
